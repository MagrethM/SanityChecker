/*
 * Extremenetworks, Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.opendaylight.sanitychecker.impl;

import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.ProviderContext;
import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.RpcRegistration;
import org.opendaylight.controller.sal.binding.api.BindingAwareProvider;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.sanitychecker.rev150105.SanitycheckerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SanitycheckerProvider implements BindingAwareProvider, AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(SanitycheckerProvider.class);
    private RpcRegistration<SanitycheckerService> sanitycheckerService;

    @Override
    public void onSessionInitiated(ProviderContext session) {
        LOG.info("SanitycheckerProvider Session Initiated");
        sanitycheckerService = session.addRpcImplementation(SanitycheckerService.class, new SanityCheckerImpl());
    }

    @Override
    public void close() throws Exception {
        LOG.info("SanitycheckerProvider Closed");
       if (sanitycheckerService != null) {
            sanitycheckerService.close();
        }
    }

}
