/*
 * Copyright © 2015 ExtremeNetworks, Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */

package org.opendaylight.sanitychecker.impl;

import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.sanitychecker.rev150105.SanitycheckerInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.sanitychecker.rev150105.SanitycheckerOutput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.sanitychecker.rev150105.SanitycheckerOutputBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.sanitychecker.rev150105.SanitycheckerService;
import org.opendaylight.yangtools.yang.common.RpcResult;
import org.opendaylight.yangtools.yang.common.RpcResultBuilder;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Future;



public class SanityCheckerImpl implements SanitycheckerService {

    String Bname2,Pname2,inconfig,secCommand,endresult,thirdCommand,fourthCommand,postURL,input,result,delURL,Iname,iURL,iURL1,ikey,fifthCommand,accessvlan,vlanlist,trunk1,trunk2,trunk3;
    JsonObject jsonObjectN=null;
    JsonObject IinnerJsonObject2=null;
    JsonObject IinnerJsonObject4=null;
    JsonObject IinnerJsonObject5=null;
    JsonObject IinnerJsonObject8=null;
    JsonObject IinnerJsonObject10=null;
    JsonArray IinnerJsonObject1,IinnerJsonObject3,IinnerJsonObject7,IinnerJsonObject9,TermPoint;
    public String[] vlans;
    public List<String> commands;
    String line = null;
    ArrayList<String> trunkList= new ArrayList<String>();
    ArrayList<String> ActvPorts = new ArrayList<String>();
    ArrayList<Integer> Trunkvlan = new ArrayList<Integer>();

    @Override
    public Future<RpcResult<SanitycheckerOutput>> sanitychecker(SanitycheckerInput input) {
        SanitycheckerOutputBuilder sanityBuilder = new SanitycheckerOutputBuilder();
        inconfig = input.getInConfig();
        //Check if it is a file or a single line command
        File file = new File(inconfig);
        if (file.isFile())
        {
            sanityBuilder.setConfigResponse(ReadTheFile(inconfig));
        } else {
            mainIf();
            sanityBuilder.setConfigResponse(mainIf());

        }

        return RpcResultBuilder.success(sanityBuilder.build()).buildFuture();
    }

 public String mainIf()

 {
  commands = Arrays.asList(inconfig.split(" "));
     if (!commands.get(0).equals("ovs-vsctl") || !(commands.size() >= 4 && commands.size() <= 7))
     {
         endresult = "Your command/file path is not valid, please enter a valid OVS command/path";
     }
     else
     {
         secCommand= commands.get(1);
         thirdCommand=commands.get(2);
         fourthCommand = commands.get(3);

         if (commands.size()==5) {
             fifthCommand = commands.get(4);
             vlanlist=fifthCommand.substring(fifthCommand.lastIndexOf("=") + 1);
             if (vlanlist.contains(",")) {
                 vlans = vlanlist.split(",");
             }else
                 accessvlan=vlanlist;

         }
         if (secCommand.equals("add-port") && (commands.size()==4 || commands.size()==5 ))
             endresult = CheckAdd();
         else if (secCommand.equals("del-port") && commands.size()==4 )
             endresult = CheckPort();
         else if (secCommand.equals("set") && commands.size()==5)
             endresult = CheckTrunkUpdate();
         else if (secCommand.equals("add-bond") && (commands.size()==6 || commands.size()==7)) {
             endresult = CheckBond();
         }else
             endresult = "Your command is not valid OVS command or it is not checked by this plugin";

     }

     return endresult;
 }


    public String ReadTheFile(String path) {

        String newLine = System.getProperty("line.separator");
        String pathToWrite = System.getProperty("user.home") + File.separator + "response.txt";

        try {
            FileReader fileReader = new FileReader(path);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            FileWriter fw = new FileWriter(pathToWrite);
            BufferedWriter out = new BufferedWriter(fw);

            while((line = bufferedReader.readLine()) != null) {
                inconfig=line;
                String response=mainIf();
                out.write(response+newLine);
            }
            bufferedReader.close();
            out.close();
            result= "The response to your configuration commands is available at "+pathToWrite;
        }
        catch(IOException ex) {
            result="Error reading file at '"+ path + "'";

        }
        return result;
    }


    public String CheckAdd() {

        try {
            postURL = "http://192.168.113.167:8181/restconf/config/network-topology:network-topology/topology/ovsdb:1/node/ovsdb:%2F%2F192.168.113.167:16640%2Fbridge%2F" + thirdCommand + "/termination-point/" + fourthCommand + "/";

            if (inconfig.contains("tag")) {
                input = "{\"network-topology:termination-point\":[{\"ovsdb:options\":[{\"ovsdb:option\":\"remote_ip\",\"ovsdb:value\":\"192.168.113.167\"}],\"ovsdb:name\":\"" + fourthCommand + "\",\"ovsdb:interface-type\":\"internal\",\"tp-id\":\"" + fourthCommand + "\",\"vlan-tag\":\"" + accessvlan + "\",\"vlan-mode\":\"access\"}]}";
                PutCurl(postURL, input);
                result = "The port was successful added";
            } else if (inconfig.contains("trunk")) {

                for (int i = 0; i < vlans.length; i++) {
                    String trunks = "{\"trunk\":\"" + vlans[i] + "\"}";
                    trunkList.add(trunks);
                }
                input = "{\"network-topology:termination-point\":[{\"ovsdb:options\":[{\"ovsdb:option\":\"remote_ip\",\"ovsdb:value\":\"192.168.113.167\"}],\"ovsdb:name\":\"" + fourthCommand + "\",\"ovsdb:interface-type\":\"internal\",\"tp-id\":\"" + fourthCommand + "\",\"trunks\":" + trunkList.toString() + ",\"vlan-mode\":\"trunk\"}]}";
                PutCurl(postURL, input);
                result = "The port was successful added";
            } else
                result = "The port you are creating will be a trunk by default allowing all available VLANs. This poses a security risk, specify allowed VLANs or make it an access port";
        }catch(Exception ex)
        {
            result = "There was an error processing your request, please check log";
        }
        return result;
    }

    public String CheckPort()
    {
    try{
        iURL = "http://192.168.113.167:8181/restconf/operational/network-topology:network-topology/topology/ovsdb:1/";
        JsonObject IinnerJsonObject=GetCurl(iURL);
        IinnerJsonObject1=IinnerJsonObject.getJsonArray("topology");
        IinnerJsonObject2 = IinnerJsonObject1.getJsonObject(0);
        IinnerJsonObject3=IinnerJsonObject2.getJsonArray("node");
        for(int j = 0; j < IinnerJsonObject3.size(); j++)
        {
            IinnerJsonObject4 = IinnerJsonObject3.getJsonObject(j);
            if (IinnerJsonObject4.containsKey("termination-point"))
            {
                TermPoint=IinnerJsonObject4.getJsonArray("termination-point");
                for(int k = 0; k < TermPoint.size(); k++)
                {
                    IinnerJsonObject5 = TermPoint.getJsonObject(k);
                    Pname2 = IinnerJsonObject5.getString("tp-id");
                    ActvPorts.add(Pname2);
                }

            }

        }
        if (ActvPorts.contains(fourthCommand))
        {
            result = "The port you are trying to delete is active, deleting this port will result in lost connection";
        }
        else
        {
            delURL="http://192.168.113.167:8181/restconf/config/network-topology:network-topology/topology/ovsdb:1/node/ovsdb:%2F%2F192.168.113.167:16640%2Fbridge%2F"+thirdCommand+"/termination-point/"+fourthCommand+"/";
            DeleteCurl(delURL);
            result = "The port was successful deleted";
        }
    }catch(Exception ex)
    {
        result = "There was an error processing your request, please check log";
    }
        return result;
    }

    public String CheckBond()
    {
        try{
            if (inconfig.contains("lacp") )
            {

                if (inconfig.contains("tag")){
                    //add bond
                    result = "The bond was successful added";
                }else
                if (inconfig.contains("trunk")) {
                    //add bond
                    result = "The bond was successful added";
                }else
                    result = "The bond you are creating will be a trunk by default allowing all available VLANs. This poses a security risk, specify allowed VLANs or make it an access port";

            }else
            {
                result = "The bond you are trying to add is not activated, specify lacp=active in your command to activate the bond";
            }
        }catch(Exception ex)
        {
            result = "There was an error processing your request, please check log";
        }
        return result;
    }

    public String CheckTrunkUpdate() {
    try{
        iURL = "http://192.168.113.167:8181/restconf/config/network-topology:network-topology/topology/ovsdb:1";
        JsonObject IinnerJsonObject=GetCurl(iURL);

        IinnerJsonObject1=IinnerJsonObject.getJsonArray("topology");
            IinnerJsonObject2 = IinnerJsonObject1.getJsonObject(0);
            IinnerJsonObject3=IinnerJsonObject2.getJsonArray("node");
            for(int j = 0; j < IinnerJsonObject3.size(); j++)
            {
                IinnerJsonObject4 = IinnerJsonObject3.getJsonObject(j);
                if (IinnerJsonObject4.containsKey("ovsdb:bridge-name"))
                {
                    Bname2 = IinnerJsonObject4.getString("ovsdb:bridge-name");
                    if (IinnerJsonObject4.containsKey("termination-point"))
                    {
                        TermPoint=IinnerJsonObject4.getJsonArray("termination-point");
                        for(int k = 0; k < TermPoint.size(); k++)
                        {
                            IinnerJsonObject5 = TermPoint.getJsonObject(k);
                            Pname2 = IinnerJsonObject5.getString("tp-id");
                            if (Pname2.equals(fourthCommand))
                            {
                                thirdCommand=Bname2;
                                iURL1 = "http://192.168.113.167:8181/restconf/config/network-topology:network-topology/topology/ovsdb:1/node/ovsdb:%2F%2F1192.168.113.167:16640%2Fbridge%2F"+thirdCommand+"/termination-point/"+fourthCommand+"/";
                            }

                        }
                    }

                }

            }
        JsonObject IinnerJsonObject6=GetCurl(iURL1);
        IinnerJsonObject7=IinnerJsonObject6.getJsonArray("termination-point");

            IinnerJsonObject8 = IinnerJsonObject7.getJsonObject(0);
            if (IinnerJsonObject8.containsKey("ovsdb:trunks"))
            {
                IinnerJsonObject9=IinnerJsonObject8.getJsonArray("ovsdb:trunks");
                for(int k = 0; k < IinnerJsonObject9.size(); k++)
                {
                IinnerJsonObject10 = IinnerJsonObject9.getJsonObject(k);
                Trunkvlan.add(IinnerJsonObject10.getInt("trunk"));
                }
                result ="The port has vlans already, adding these vlans with replace existing vlans";
            }else
            {
                postURL = "http://192.168.113.167:8181/restconf/config/network-topology:network-topology/topology/ovsdb:1/node/ovsdb:%2F%2F192.168.113.167:16640%2Fbridge%2F" + thirdCommand + "/termination-point/" + fourthCommand + "/";
                for(int j=0;j<vlans.length;j++)
                {
                    String trunks= "{\"trunk\":\""+vlans[j]+"\"}";
                    trunkList.add(trunks);
                }
                input = "{\"network-topology:termination-point\":[{\"ovsdb:options\":[{\"ovsdb:option\":\"remote_ip\",\"ovsdb:value\":\"192.168.113.167\"}],\"ovsdb:name\":\""+fourthCommand+"\",\"ovsdb:interface-type\":\"internal\",\"tp-id\":\""+fourthCommand+"\",\"trunks\":"+trunkList.toString()+",\"vlan-mode\":\"trunk\"}]}";
                PutCurl(postURL, input);
                result = "The port was successful updated";

            }
        //}
    }catch(Exception ex)
    {
    result = "There was an error processing your request, please check log";
    }
        return result;
    }

    public JsonObject GetCurl (String urlToSend) {
        ProcessBuilder p = new ProcessBuilder("curl", "--show-error", "--request", "GET",
                "--header", "Accept: application/json", "--user", "admin:admin", urlToSend);
          try {
            final Process shell = p.start();
            JsonReader jsonReader = Json.createReader(new InputStreamReader(shell.getInputStream()));
            jsonObjectN = jsonReader.readObject();
            jsonReader.close();
           } catch (IOException ex) {
            ex.printStackTrace();
        }
        return jsonObjectN;
    }

    public void PutCurl (String urlToSend, String parameters ) {
        //ProcessBuilder p = new ProcessBuilder("curl", "-u", "admin:admin", "-i", urlToSend, "-X", "PUT", "-H","Pragma: no-cache", "-H", "Content-Type:application/json", "-H", "Accept:application/json", "-d"+parameters);
        ProcessBuilder p = new ProcessBuilder("curl", "-u", "admin:admin", "-i", urlToSend, "-X", "PUT",
               "-H", "Content-Type:application/json", "-H", "Accept:application/json", "-d"+parameters);
        try {
            p.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void DeleteCurl (String urlToSend) {
        ProcessBuilder p = new ProcessBuilder("curl", "-u", "admin:admin", "-i", urlToSend, "-X", "DELETE",
                "-H", "Content-Type: application/json", "-H", "Accept: application/json");
        try {
            p.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }


}


