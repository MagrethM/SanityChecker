package org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.sanitychecker.rev150105;
import java.util.concurrent.Future;
import org.opendaylight.yangtools.yang.binding.RpcService;
import org.opendaylight.yangtools.yang.common.RpcResult;


/**
 * Interface for implementing the following YANG RPCs defined in module &lt;b&gt;sanitychecker&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/sanitychecker.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * rpc sanitychecker {
 *     input {
 *         leaf inConfig {
 *             type string;
 *         }
 *     }
 *     
 *     output {
 *         leaf configResponse {
 *             type string;
 *         }
 *     }
 *     status CURRENT;
 * }
 * &lt;/pre&gt;
 *
 */
public interface SanitycheckerService
    extends
    RpcService
{




    Future<RpcResult<SanitycheckerOutput>> sanitychecker(SanitycheckerInput input);

}

